# -*- coding: utf-8 -*-
"""Shared User-Agent values for SubsSupport seekers.

Browser-style User-Agent strings are used only when fetching regular web pages
or temporary download links. REST API requests use the plugin's stable
application identity. A browser User-Agent is selected once per process/session
and reused by providers so one HTTP session does not rotate identities between
search, details and download requests.
"""
from __future__ import absolute_import

import random

# Stable identity for REST API requests. OpenSubtitles expects an application
# name and version rather than a randomized browser identity. Update this value
# when releasing a new plugin version.
API_USER_AGENT = "SubsSupportPro v1.0.2"

# Modern browser-style User-Agent strings for ordinary web requests.  Keep these
# realistic and internally consistent; providers should reuse one chosen value
# through get_session_ua() instead of changing it on every request.
USER_AGENTS = [
    # Chrome / Chromium - Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",

    # Chrome / Chromium - macOS
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",

    # Chrome / Chromium - Linux
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",

    # Microsoft Edge - Windows/macOS
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0",

    # Firefox - Windows/macOS/Linux
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.6; rv:139.0) Gecko/20100101 Firefox/139.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:139.0) Gecko/20100101 Firefox/139.0",

    # Safari - macOS/iOS/iPadOS
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 15_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPad; CPU OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1",

    # Android Chrome
    "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 15; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36",
]

_SESSION_USER_AGENT = None
_SESSION_USER_AGENTS = {}


def _choose_ua():
    return random.choice(USER_AGENTS)


def get_session_ua(session_key=None):
    """Return one stable browser User-Agent for the current process/session.

    If *session_key* is supplied, each key gets its own stable value.  This lets
    providers keep the same UA for a request.Session without rotating identity
    between page fetches and downloads.
    """
    global _SESSION_USER_AGENT
    if session_key is None:
        if _SESSION_USER_AGENT is None:
            _SESSION_USER_AGENT = _choose_ua()
        return _SESSION_USER_AGENT
    if session_key not in _SESSION_USER_AGENTS:
        _SESSION_USER_AGENTS[session_key] = _choose_ua()
    return _SESSION_USER_AGENTS[session_key]


def reset_session_ua(session_key=None):
    """Reset the cached UA. Intended for manual troubleshooting only."""
    global _SESSION_USER_AGENT
    if session_key is None:
        _SESSION_USER_AGENT = _choose_ua()
        return _SESSION_USER_AGENT
    _SESSION_USER_AGENTS[session_key] = _choose_ua()
    return _SESSION_USER_AGENTS[session_key]


def get_random_ua():
    """Backward-compatible name: returns the stable session User-Agent."""
    return get_session_ua()


def get_api_user_agent():
    """Return the stable application identity required by REST APIs."""
    return API_USER_AGENT
