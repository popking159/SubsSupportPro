# -*- coding: utf-8 -*-
VER = "1.0.1"
PLUGIN_VERSION_TITLE = "SubsSupportPro %s" % VER
